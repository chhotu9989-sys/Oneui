package com.orbit.launcher

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.BlurredEdgeTreatment
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.layout.layout
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin

/** Shared animation state: wallpaper clock, device tilt and pager position. */
class AuroraState {
    var t by mutableFloatStateOf(0f)
    var tx by mutableFloatStateOf(0f)
    var ty by mutableFloatStateOf(0f)
    var page by mutableFloatStateOf(0f)
}

val LocalAurora = staticCompositionLocalOf<AuroraState> { error("AuroraState not provided") }
val LocalScreen = staticCompositionLocalOf { IntSize(1080, 2400) }

private class Blob(
    val color: Color,
    val bx: Float,
    val by: Float,
    val r: Float,
    val sp: Float,
    val ph: Float,
    val depth: Float
)

private val blobs = listOf(
    Blob(Color(0xFF5B5CFF), 0.25f, 0.18f, 0.85f, 0.13f, 0f, 1.0f),
    Blob(Color(0xFF16C3B5), 0.80f, 0.45f, 0.80f, 0.10f, 2f, 1.6f),
    Blob(Color(0xFFFF4F9A), 0.30f, 0.85f, 0.75f, 0.12f, 4f, 1.3f),
    Blob(Color(0xFFFFA14A), 0.85f, 0.10f, 0.55f, 0.09f, 1f, 2.0f)
)

private class Star(
    val x: Float,
    val y: Float,
    val r: Float,
    val sp: Float,
    val ph: Float,
    val depth: Float
)

private val stars: List<Star> = run {
    val rnd = kotlin.random.Random(11)
    List(90) {
        Star(
            x = rnd.nextFloat(),
            y = rnd.nextFloat(),
            r = 0.6f + rnd.nextFloat() * 1.8f,
            sp = 0.4f + rnd.nextFloat() * 1.4f,
            ph = rnd.nextFloat() * 6.28f,
            depth = 0.5f + rnd.nextFloat() * 2.5f
        )
    }
}

/**
 * The wallpaper. Slow colour fields, orbit rings and a dust of stars sit at different depths,
 * so tilting the phone or swiping between pages slides each layer by a different amount.
 * The fine detail matters: it is what the frosted glass panels blur.
 */
fun DrawScope.drawAurora(a: AuroraState) {
    val w = size.width
    val h = size.height
    if (w <= 0f || h <= 0f) return
    drawRect(Color(0xFF070914))
    val t = a.t

    for (b in blobs) {
        val cx = w * (b.bx + 0.09f * sin(t * b.sp * 6.2832f + b.ph)) +
            a.tx * w * 0.045f * b.depth - a.page * w * 0.10f * b.depth
        val cy = h * (b.by + 0.06f * cos(t * b.sp * 5f + b.ph)) + a.ty * h * 0.03f * b.depth
        val r = w * b.r
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(b.color.copy(alpha = 0.62f), Color.Transparent),
                center = Offset(cx, cy),
                radius = r
            ),
            radius = r,
            center = Offset(cx, cy)
        )
    }

    val ocx = w * 0.5f - a.page * w * 0.08f + a.tx * w * 0.03f
    val ocy = h * 0.42f + a.ty * h * 0.02f
    rotate(degrees = t * 3f, pivot = Offset(ocx, ocy)) {
        drawOval(
            color = Color.White.copy(alpha = 0.08f),
            topLeft = Offset(ocx - w * 0.62f, ocy - h * 0.16f),
            size = Size(w * 1.24f, h * 0.32f),
            style = Stroke(width = 2f)
        )
    }
    rotate(degrees = -t * 2f + 40f, pivot = Offset(ocx, ocy)) {
        drawOval(
            color = Color.White.copy(alpha = 0.06f),
            topLeft = Offset(ocx - w * 0.45f, ocy - h * 0.10f),
            size = Size(w * 0.90f, h * 0.20f),
            style = Stroke(width = 2f)
        )
    }

    for (s in stars) {
        val x = (((s.x * w + a.tx * w * 0.03f * s.depth - a.page * w * 0.08f * s.depth) % w) + w) % w
        val y = s.y * h + a.ty * h * 0.02f * s.depth
        val alpha = 0.22f + 0.30f * (0.5f + 0.5f * sin(t * s.sp + s.ph))
        drawCircle(Color.White.copy(alpha = alpha), radius = s.r * (w / 520f), center = Offset(x, y))
    }
}

@Composable
fun Aurora(modifier: Modifier = Modifier) {
    val a = LocalAurora.current
    Canvas(modifier) { drawAurora(a) }
}

/** Drives the wallpaper clock and reads the gravity sensor for the tilt parallax. */
@Composable
fun rememberAurora(): AuroraState {
    val a = remember { AuroraState() }
    val ctx = LocalContext.current
    val owner = LocalLifecycleOwner.current

    LaunchedEffect(Unit) {
        val start = androidx.compose.runtime.withFrameNanos { it }
        while (true) {
            androidx.compose.runtime.withFrameNanos { n ->
                a.t = ((n - start) / 1_000_000L).toFloat() / 1000f
            }
        }
    }

    DisposableEffect(owner) {
        val sm = ctx.getSystemService(Context.SENSOR_SERVICE) as SensorManager
        val sensor = sm.getDefaultSensor(Sensor.TYPE_GRAVITY)
            ?: sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        val listener = object : SensorEventListener {
            override fun onSensorChanged(e: SensorEvent) {
                val x = (-e.values[0] / 9.81f).coerceIn(-1f, 1f)
                val y = ((e.values[1] / 9.81f) - 0.55f).coerceIn(-1f, 1f)
                a.tx = a.tx + (x - a.tx) * 0.07f
                a.ty = a.ty + (y - a.ty) * 0.07f
            }

            override fun onAccuracyChanged(s: Sensor?, accuracy: Int) {}
        }
        val observer = LifecycleEventObserver { _, event ->
            if (sensor != null) {
                if (event == Lifecycle.Event.ON_RESUME) {
                    sm.registerListener(listener, sensor, SensorManager.SENSOR_DELAY_GAME)
                } else if (event == Lifecycle.Event.ON_PAUSE) {
                    sm.unregisterListener(listener)
                }
            }
        }
        owner.lifecycle.addObserver(observer)
        onDispose {
            owner.lifecycle.removeObserver(observer)
            sm.unregisterListener(listener)
        }
    }
    return a
}

/**
 * Frosted glass. It redraws the wallpaper, aligned to the window and blurred, inside the panel,
 * then adds a tint, a light sheen that follows the tilt, a rim highlight and a soft shadow.
 */
@Composable
fun GlassPanel(
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(32.dp),
    blurRadius: Dp = 26.dp,
    tint: Brush = Brush.verticalGradient(
        listOf(Color.White.copy(alpha = 0.20f), Color.White.copy(alpha = 0.07f))
    ),
    originProvider: (() -> Offset)? = null,
    content: @Composable BoxScope.() -> Unit
) {
    val a = LocalAurora.current
    val screen = LocalScreen.current
    var origin by remember { mutableStateOf(Offset.Zero) }

    Box(
        modifier
            .onGloballyPositioned { origin = it.positionInRoot() }
            .shadow(
                elevation = 20.dp,
                shape = shape,
                ambientColor = Color.Black.copy(alpha = 0.30f),
                spotColor = Color.Black.copy(alpha = 0.40f)
            )
            .clip(shape)
            .border(
                1.dp,
                Brush.linearGradient(
                    listOf(
                        Color.White.copy(alpha = 0.60f),
                        Color.White.copy(alpha = 0.06f),
                        Color.White.copy(alpha = 0.28f)
                    )
                ),
                shape
            )
    ) {
        Box(Modifier.matchParentSize()) {
            Canvas(
                Modifier
                    .layout { measurable, constraints ->
                        val p = measurable.measure(
                            Constraints.fixed(
                                screen.width.coerceAtLeast(1),
                                screen.height.coerceAtLeast(1)
                            )
                        )
                        layout(constraints.maxWidth, constraints.maxHeight) {
                            val o = originProvider?.invoke() ?: origin
                            p.place(-o.x.roundToInt(), -o.y.roundToInt())
                        }
                    }
                    .blur(blurRadius, BlurredEdgeTreatment.Unbounded)
            ) {
                drawAurora(a)
            }
        }
        Box(Modifier.matchParentSize().background(tint))
        Box(
            Modifier
                .matchParentSize()
                .drawBehind {
                    drawRect(
                        Brush.linearGradient(
                            colors = listOf(Color.White.copy(alpha = 0.20f), Color.Transparent),
                            start = Offset(size.width * (0.05f + a.tx * 0.45f), 0f),
                            end = Offset(size.width * (0.75f + a.tx * 0.45f), size.height)
                        )
                    )
                }
        )
        content()
    }
}
