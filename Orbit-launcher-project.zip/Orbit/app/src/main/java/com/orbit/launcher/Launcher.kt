package com.orbit.launcher

import android.content.Context
import android.view.HapticFeedbackConstants
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.PagerState
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.min

@Composable
fun LauncherRoot(homeSignal: Int, reloadSignal: Int) {
    val ctx = LocalContext.current
    val view = LocalView.current
    val scope = rememberCoroutineScope()
    val aurora = rememberAurora()

    var screen by remember { mutableStateOf(IntSize(1080, 2400)) }
    var apps by remember { mutableStateOf<List<AppItem>>(emptyList()) }
    LaunchedEffect(reloadSignal) {
        apps = withContext(Dispatchers.Default) { AppLoader.load(ctx) }
    }
    val dock = remember(apps) { AppLoader.defaultDock(ctx, apps) }
    val homeApps = remember(apps, dock) { apps.filter { a -> dock.none { it.pkg == a.pkg } } }

    val progress = remember { Animatable(0f).apply { updateBounds(0f, 1f) } }
    var query by remember { mutableStateOf("") }
    var menuApp by remember { mutableStateOf<AppItem?>(null) }
    var menuVisible by remember { mutableStateOf(false) }
    val hPx = screen.height.toFloat().coerceAtLeast(1f)

    val tap: () -> Unit = {
        try {
            view.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
        } catch (_: Exception) {
        }
    }
    val onOpen: (AppItem, Rect) -> Unit = { app, r ->
        tap()
        AppLoader.launch(ctx, view, app, r)
        scope.launch {
            delay(450)
            progress.snapTo(0f)
            query = ""
        }
    }
    val onMenu: (AppItem, Rect) -> Unit = { app, _ ->
        tap()
        menuApp = app
        menuVisible = true
    }

    val dragState = rememberDraggableState { delta ->
        scope.launch { progress.snapTo((progress.value - delta / hPx).coerceIn(0f, 1f)) }
    }
    val settle: suspend (Float) -> Unit = { v ->
        val target = when {
            v < -900f -> 1f
            v > 900f -> 0f
            progress.value > 0.5f -> 1f
            else -> 0f
        }
        progress.animateTo(
            target,
            spring(dampingRatio = 0.85f, stiffness = 300f),
            initialVelocity = -v / hPx
        )
    }

    BackHandler(enabled = true) {
        if (menuVisible) {
            menuVisible = false
        } else if (progress.value > 0.01f) {
            scope.launch { progress.animateTo(0f, spring(dampingRatio = 0.85f, stiffness = 300f)) }
        }
    }

    CompositionLocalProvider(LocalAurora provides aurora, LocalScreen provides screen) {
        Box(
            Modifier
                .fillMaxSize()
                .onSizeChanged { screen = it }
        ) {
            Aurora(Modifier.fillMaxSize())

            // ---------- Home layer: pages, dots, dock ----------
            Column(
                Modifier
                    .fillMaxSize()
                    .draggable(
                        state = dragState,
                        orientation = Orientation.Vertical,
                        onDragStarted = { progress.stop() },
                        onDragStopped = { v -> settle(v) }
                    )
                    .graphicsLayer {
                        val p = progress.value
                        scaleX = 1f - 0.08f * p
                        scaleY = 1f - 0.08f * p
                        alpha = 1f - 0.85f * p
                    }
                    .statusBarsPadding()
                    .navigationBarsPadding()
            ) {
                BoxWithConstraints(
                    Modifier
                        .weight(1f)
                        .fillMaxWidth()
                ) {
                    val cellW = maxWidth / 4
                    val iconSize = cellW * 0.66f
                    val rowH = iconSize + 40.dp
                    val avail = maxHeight - 30.dp
                    val widgetH = 156.dp
                    val rows0 = ((avail - widgetH) / rowH).toInt().coerceAtLeast(2)
                    val rowsN = (avail / rowH).toInt().coerceIn(3, 7)
                    val pages = remember(homeApps, rows0, rowsN) {
                        val first = homeApps.take(rows0 * 4)
                        listOf(first) + homeApps.drop(first.size).chunked(rowsN * 4)
                    }
                    val pagerState = rememberPagerState(pageCount = { pages.size })

                    LaunchedEffect(pagerState) {
                        snapshotFlow { pagerState.currentPage + pagerState.currentPageOffsetFraction }
                            .collect { aurora.page = it }
                    }
                    LaunchedEffect(homeSignal) {
                        if (homeSignal > 0) {
                            menuVisible = false
                            query = ""
                            launch { progress.animateTo(0f, spring(dampingRatio = 0.85f, stiffness = 300f)) }
                            pagerState.animateScrollToPage(0)
                        }
                    }

                    HorizontalPager(state = pagerState, modifier = Modifier.fillMaxSize()) { page ->
                        val off: () -> Float = {
                            (pagerState.currentPage - page) + pagerState.currentPageOffsetFraction
                        }
                        Column(
                            Modifier
                                .fillMaxSize()
                                .graphicsLayer {
                                    val o = off()
                                    val k = min(abs(o), 1f)
                                    alpha = 1f - 0.7f * k
                                    scaleX = 1f - 0.10f * k
                                    scaleY = 1f - 0.10f * k
                                    rotationY = o.coerceIn(-1f, 1f) * -16f
                                    cameraDistance = 12f * density
                                }
                                .padding(top = 8.dp),
                            verticalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            if (page == 0) {
                                ClockWidget(Modifier.padding(horizontal = 14.dp))
                            }
                            PageGrid(
                                apps = pages.getOrElse(page) { emptyList() },
                                rows = if (page == 0) rows0 else rowsN,
                                iconSize = iconSize,
                                offset = off,
                                onOpen = onOpen,
                                onMenu = onMenu
                            )
                        }
                    }

                    PageDots(
                        pagerState,
                        Modifier
                            .align(Alignment.BottomCenter)
                            .padding(bottom = 8.dp)
                    )
                }

                GlassPanel(
                    Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp)
                        .height(96.dp),
                    RoundedCornerShape(36.dp)
                ) {
                    Row(
                        Modifier
                            .fillMaxSize()
                            .padding(horizontal = 6.dp),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        dock.forEach { app ->
                            AppIcon(app, 60.dp, false, onOpen, onMenu, depth = 1.6f)
                        }
                    }
                }
                Spacer(Modifier.height(10.dp))
            }

            // ---------- App drawer, pulled up from the bottom ----------
            Box(
                Modifier
                    .fillMaxSize()
                    .graphicsLayer { translationY = (1f - progress.value) * size.height }
            ) {
                GlassPanel(
                    Modifier.fillMaxSize(),
                    RoundedCornerShape(topStart = 38.dp, topEnd = 38.dp),
                    blurRadius = 38.dp,
                    tint = Brush.verticalGradient(
                        listOf(
                            Color(0xFF0B0E1C).copy(alpha = 0.55f),
                            Color(0xFF0B0E1C).copy(alpha = 0.38f)
                        )
                    ),
                    originProvider = { Offset(0f, (1f - progress.value) * hPx) }
                ) {
                    Column(
                        Modifier
                            .fillMaxSize()
                            .statusBarsPadding()
                            .navigationBarsPadding()
                            .imePadding()
                            .padding(horizontal = 16.dp)
                    ) {
                        Box(
                            Modifier
                                .fillMaxWidth()
                                .height(34.dp)
                                .draggable(
                                    state = dragState,
                                    orientation = Orientation.Vertical,
                                    onDragStarted = { progress.stop() },
                                    onDragStopped = { v -> settle(v) }
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Box(
                                Modifier
                                    .width(44.dp)
                                    .height(5.dp)
                                    .clip(RoundedCornerShape(3.dp))
                                    .background(Color.White.copy(alpha = 0.5f))
                            )
                        }

                        val filtered = remember(apps, query) {
                            if (query.isBlank()) apps
                            else apps.filter { it.label.contains(query.trim(), ignoreCase = true) }
                        }

                        SearchField(
                            value = query,
                            onValueChange = { query = it },
                            onGo = { filtered.firstOrNull()?.let { a -> onOpen(a, Rect.Zero) } }
                        )
                        Spacer(Modifier.height(14.dp))

                        if (filtered.isEmpty()) {
                            BasicText(
                                "No apps found",
                                Modifier
                                    .fillMaxWidth()
                                    .padding(top = 40.dp),
                                style = TextStyle(
                                    color = Color.White.copy(alpha = 0.6f),
                                    fontSize = 15.sp,
                                    textAlign = TextAlign.Center
                                )
                            )
                        }

                        LazyVerticalGrid(
                            columns = GridCells.Fixed(4),
                            modifier = Modifier.fillMaxSize(),
                            contentPadding = PaddingValues(top = 6.dp, bottom = 32.dp),
                            verticalArrangement = Arrangement.spacedBy(20.dp)
                        ) {
                            itemsIndexed(filtered, key = { _, a -> a.pkg + "/" + a.cls }) { i, app ->
                                Box(
                                    Modifier
                                        .fillMaxWidth()
                                        .graphicsLayer {
                                            val k = (progress.value * 1.7f - 0.35f - (i / 4) * 0.07f)
                                                .coerceIn(0f, 1f)
                                            alpha = k
                                            translationY = (1f - k) * 70f
                                            scaleX = 0.8f + 0.2f * k
                                            scaleY = 0.8f + 0.2f * k
                                        },
                                    contentAlignment = Alignment.Center
                                ) {
                                    AppIcon(app, 60.dp, true, onOpen, onMenu)
                                }
                            }
                        }
                    }
                }
            }

            // ---------- Long-press menu ----------
            AnimatedVisibility(menuVisible, enter = fadeIn(), exit = fadeOut()) {
                Box(
                    Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(alpha = 0.45f))
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null
                        ) { menuVisible = false }
                )
            }
            AnimatedVisibility(
                menuVisible,
                Modifier.align(Alignment.Center),
                enter = scaleIn(spring(dampingRatio = 0.62f, stiffness = 380f), initialScale = 0.6f) + fadeIn(),
                exit = scaleOut(targetScale = 0.85f) + fadeOut()
            ) {
                val app = menuApp
                if (app != null) {
                    MenuCard(
                        app = app,
                        onInfo = {
                            menuVisible = false
                            AppLoader.showInfo(ctx, app)
                        },
                        onUninstall = {
                            menuVisible = false
                            AppLoader.uninstall(ctx, app)
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun PageGrid(
    apps: List<AppItem>,
    rows: Int,
    iconSize: Dp,
    offset: () -> Float,
    onOpen: (AppItem, Rect) -> Unit,
    onMenu: (AppItem, Rect) -> Unit
) {
    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        apps.chunked(4).forEachIndexed { r, row ->
            Row(Modifier.fillMaxWidth()) {
                for (c in 0 until 4) {
                    Box(
                        Modifier
                            .weight(1f)
                            .graphicsLayer {
                                // Lower rows trail the swipe a little more, which gives the page a wave.
                                translationX = offset() * size.width * 0.35f * ((r + 1f) / rows.coerceAtLeast(1))
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        val app = row.getOrNull(c)
                        if (app != null) AppIcon(app, iconSize, true, onOpen, onMenu)
                    }
                }
            }
        }
    }
}

@Composable
fun AppIcon(
    app: AppItem,
    size: Dp,
    showLabel: Boolean,
    onOpen: (AppItem, Rect) -> Unit,
    onMenu: (AppItem, Rect) -> Unit,
    modifier: Modifier = Modifier,
    depth: Float = 1f
) {
    val a = LocalAurora.current
    var rect by remember { mutableStateOf(Rect.Zero) }
    var pressed by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(
        targetValue = if (pressed) 0.84f else 1f,
        animationSpec = spring(dampingRatio = 0.45f, stiffness = 420f),
        label = "press"
    )
    val shape = RoundedCornerShape((size.value * 0.28f).dp)

    Column(
        modifier
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
                translationX = a.tx * 4.dp.toPx() * depth
                translationY = -a.ty * 3.dp.toPx() * depth
            }
            .pointerInput(app) {
                detectTapGestures(
                    onPress = {
                        pressed = true
                        tryAwaitRelease()
                        pressed = false
                    },
                    onTap = { onOpen(app, rect) },
                    onLongPress = { onMenu(app, rect) }
                )
            },
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            Modifier
                .size(size)
                .onGloballyPositioned { rect = it.boundsInRoot() }
                .shadow(
                    12.dp,
                    shape,
                    ambientColor = Color.Black.copy(alpha = 0.35f),
                    spotColor = Color.Black.copy(alpha = 0.45f)
                )
                .clip(shape)
                .drawWithContent {
                    drawContent()
                    drawRect(
                        Brush.verticalGradient(
                            listOf(Color.White.copy(alpha = 0.26f), Color.Transparent),
                            endY = this.size.height * 0.55f
                        )
                    )
                    drawRoundRect(
                        color = Color.White.copy(alpha = 0.22f),
                        cornerRadius = CornerRadius(this.size.width * 0.28f),
                        style = Stroke(1.dp.toPx())
                    )
                }
        ) {
            Image(bitmap = app.icon, contentDescription = app.label, modifier = Modifier.fillMaxSize())
        }
        if (showLabel) {
            Spacer(Modifier.height(6.dp))
            BasicText(
                app.label,
                Modifier.width(size + 18.dp),
                style = TextStyle(
                    color = Color.White,
                    fontSize = 11.5.sp,
                    fontWeight = FontWeight.Medium,
                    textAlign = TextAlign.Center,
                    shadow = Shadow(Color(0x88000000), Offset(0f, 2f), 6f)
                ),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
fun ClockWidget(modifier: Modifier = Modifier) {
    val now by produceState(initialValue = System.currentTimeMillis()) {
        while (true) {
            value = System.currentTimeMillis()
            delay(1000L - value % 1000L)
        }
    }
    val timeFmt = remember { SimpleDateFormat("h:mm", Locale.getDefault()) }
    val ampmFmt = remember { SimpleDateFormat("a", Locale.getDefault()) }
    val dateFmt = remember { SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()) }
    val cal = Calendar.getInstance().apply { timeInMillis = now }
    val hour = cal.get(Calendar.HOUR_OF_DAY)
    val dayFrac = (hour * 3600 + cal.get(Calendar.MINUTE) * 60 + cal.get(Calendar.SECOND)) / 86400f
    val greeting = when {
        hour < 5 -> "LATE NIGHT"
        hour < 12 -> "GOOD MORNING"
        hour < 17 -> "GOOD AFTERNOON"
        hour < 21 -> "GOOD EVENING"
        else -> "GOOD NIGHT"
    }

    GlassPanel(modifier.fillMaxWidth().height(132.dp), RoundedCornerShape(34.dp)) {
        Row(
            Modifier
                .fillMaxSize()
                .padding(horizontal = 22.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                BasicText(
                    greeting,
                    style = TextStyle(
                        color = Color.White.copy(alpha = 0.65f),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        letterSpacing = 1.6.sp
                    )
                )
                Row(verticalAlignment = Alignment.Bottom) {
                    BasicText(
                        timeFmt.format(Date(now)),
                        style = TextStyle(
                            color = Color.White,
                            fontSize = 52.sp,
                            fontWeight = FontWeight.Light,
                            letterSpacing = (-1.5).sp
                        )
                    )
                    BasicText(
                        " " + ampmFmt.format(Date(now)),
                        Modifier.padding(bottom = 10.dp),
                        style = TextStyle(color = Color.White.copy(alpha = 0.65f), fontSize = 14.sp)
                    )
                }
                BasicText(
                    dateFmt.format(Date(now)),
                    style = TextStyle(color = Color.White.copy(alpha = 0.85f), fontSize = 14.sp)
                )
            }
            Box(Modifier.size(64.dp), contentAlignment = Alignment.Center) {
                Canvas(Modifier.fillMaxSize()) {
                    val sw = 6.dp.toPx()
                    val arcSize = Size(size.width - sw, size.height - sw)
                    val topLeft = Offset(sw / 2f, sw / 2f)
                    drawArc(
                        color = Color.White.copy(alpha = 0.16f),
                        startAngle = -90f,
                        sweepAngle = 360f,
                        useCenter = false,
                        topLeft = topLeft,
                        size = arcSize,
                        style = Stroke(sw)
                    )
                    drawArc(
                        color = Color(0xFF9AA6FF),
                        startAngle = -90f,
                        sweepAngle = 360f * dayFrac,
                        useCenter = false,
                        topLeft = topLeft,
                        size = arcSize,
                        style = Stroke(sw, cap = StrokeCap.Round)
                    )
                }
                BasicText(
                    "${(dayFrac * 100).toInt()}%",
                    style = TextStyle(color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                )
            }
        }
    }
}

@Composable
fun PageDots(state: PagerState, modifier: Modifier = Modifier) {
    val pos = state.currentPage + state.currentPageOffsetFraction
    Row(
        modifier,
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        for (i in 0 until state.pageCount) {
            val t = (1f - abs(pos - i)).coerceIn(0f, 1f)
            Box(
                Modifier
                    .height(6.dp)
                    .width((6f + 14f * t).dp)
                    .clip(CircleShape)
                    .background(Color.White.copy(alpha = 0.35f + 0.55f * t))
            )
        }
    }
}

@Composable
fun SearchField(value: String, onValueChange: (String) -> Unit, onGo: () -> Unit) {
    val shape = RoundedCornerShape(25.dp)
    Box(
        Modifier
            .fillMaxWidth()
            .height(50.dp)
            .clip(shape)
            .background(Color.White.copy(alpha = 0.12f))
            .border(1.dp, Color.White.copy(alpha = 0.20f), shape)
            .padding(horizontal = 18.dp),
        contentAlignment = Alignment.CenterStart
    ) {
        if (value.isEmpty()) {
            BasicText(
                "Search apps",
                style = TextStyle(color = Color.White.copy(alpha = 0.55f), fontSize = 16.sp)
            )
        }
        BasicTextField(
            value = value,
            onValueChange = onValueChange,
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            textStyle = TextStyle(color = Color.White, fontSize = 16.sp),
            cursorBrush = SolidColor(Color.White),
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
            keyboardActions = KeyboardActions(onGo = { onGo() })
        )
    }
}

@Composable
fun MenuCard(app: AppItem, onInfo: () -> Unit, onUninstall: () -> Unit) {
    val iconShape = RoundedCornerShape(18.dp)
    GlassPanel(
        Modifier.width(250.dp),
        RoundedCornerShape(30.dp),
        tint = Brush.verticalGradient(
            listOf(Color.White.copy(alpha = 0.22f), Color.White.copy(alpha = 0.10f))
        )
    ) {
        Column(
            Modifier.padding(vertical = 18.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Image(
                bitmap = app.icon,
                contentDescription = null,
                modifier = Modifier
                    .size(64.dp)
                    .clip(iconShape)
            )
            Spacer(Modifier.height(10.dp))
            BasicText(
                app.label,
                Modifier.padding(horizontal = 16.dp),
                style = TextStyle(
                    color = Color.White,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.SemiBold,
                    textAlign = TextAlign.Center
                ),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(Modifier.height(14.dp))
            Box(Modifier.fillMaxWidth().height(1.dp).background(Color.White.copy(alpha = 0.16f)))
            MenuRow("App info", Color.White, onInfo)
            Box(Modifier.fillMaxWidth().height(1.dp).background(Color.White.copy(alpha = 0.16f)))
            MenuRow("Uninstall", Color(0xFFFF7B7B), onUninstall)
        }
    }
}

@Composable
private fun MenuRow(text: String, color: Color, onClick: () -> Unit) {
    Box(
        Modifier
            .fillMaxWidth()
            .height(50.dp)
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null
            ) { onClick() },
        contentAlignment = Alignment.Center
    ) {
        BasicText(text, style = TextStyle(color = color, fontSize = 16.sp, fontWeight = FontWeight.Medium))
    }
}
