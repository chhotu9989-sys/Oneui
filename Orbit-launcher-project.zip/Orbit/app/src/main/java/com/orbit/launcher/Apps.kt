package com.orbit.launcher

import android.app.ActivityOptions
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Path
import android.graphics.RectF
import android.graphics.drawable.AdaptiveIconDrawable
import android.graphics.drawable.Drawable
import android.net.Uri
import android.provider.MediaStore
import android.provider.Settings
import android.view.View
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.geometry.Rect as ComposeRect

data class AppItem(
    val label: String,
    val pkg: String,
    val cls: String,
    val icon: ImageBitmap
)

object AppLoader {

    /** Reads every launchable app and renders its icon into a uniform rounded tile. */
    fun load(ctx: Context): List<AppItem> {
        val pm = ctx.packageManager
        val query = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val px = (ctx.resources.displayMetrics.density * 72f).toInt().coerceAtLeast(96)
        return pm.queryIntentActivities(query, 0)
            .filter { it.activityInfo.packageName != ctx.packageName }
            .map { ri ->
                AppItem(
                    label = ri.loadLabel(pm).toString(),
                    pkg = ri.activityInfo.packageName,
                    cls = ri.activityInfo.name,
                    icon = renderIcon(ri.loadIcon(pm), px)
                )
            }
            .sortedBy { it.label.lowercase() }
    }

    private fun renderIcon(d: Drawable, s: Int): ImageBitmap {
        val bmp = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val r = s * 0.28f
        val clip = Path()
        clip.addRoundRect(RectF(0f, 0f, s.toFloat(), s.toFloat()), r, r, Path.Direction.CW)
        c.clipPath(clip)
        if (d is AdaptiveIconDrawable) {
            // The visible part of an adaptive icon is the centre two thirds of its 108dp canvas.
            val q = (s * 0.25f).toInt()
            d.background?.let {
                it.setBounds(-q, -q, s + q, s + q)
                it.draw(c)
            }
            d.foreground?.let {
                it.setBounds(-q, -q, s + q, s + q)
                it.draw(c)
            }
        } else {
            c.drawColor(0xFFF2F3F7.toInt())
            val pad = (s * 0.14f).toInt()
            d.setBounds(pad, pad, s - pad, s - pad)
            d.draw(c)
        }
        return bmp.asImageBitmap()
    }

    /** Phone, messages, browser and camera if the device has them, topped up from the app list. */
    fun defaultDock(ctx: Context, apps: List<AppItem>): List<AppItem> {
        val pm = ctx.packageManager
        val probes = listOf(
            Intent(Intent.ACTION_DIAL),
            Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:")),
            Intent(Intent.ACTION_VIEW, Uri.parse("https://example.com")),
            Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        )
        val out = mutableListOf<AppItem>()
        for (probe in probes) {
            val pkg = pm.resolveActivity(probe, PackageManager.MATCH_DEFAULT_ONLY)?.activityInfo?.packageName
                ?: continue
            val hit = apps.firstOrNull { it.pkg == pkg }
            if (hit != null && hit !in out) out.add(hit)
        }
        for (a in apps) {
            if (out.size >= 4) break
            if (a !in out) out.add(a)
        }
        return out.take(4)
    }

    fun launch(ctx: Context, view: View, app: AppItem, bounds: ComposeRect) {
        val intent = Intent(Intent.ACTION_MAIN)
            .addCategory(Intent.CATEGORY_LAUNCHER)
            .setClassName(app.pkg, app.cls)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        try {
            val opts = ActivityOptions.makeScaleUpAnimation(
                view,
                bounds.left.toInt(),
                bounds.top.toInt(),
                bounds.width.toInt().coerceAtLeast(1),
                bounds.height.toInt().coerceAtLeast(1)
            )
            ctx.startActivity(intent, opts.toBundle())
        } catch (_: Exception) {
            try {
                ctx.startActivity(intent)
            } catch (_: Exception) {
            }
        }
    }

    fun showInfo(ctx: Context, app: AppItem) {
        try {
            ctx.startActivity(
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", app.pkg, null))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (_: Exception) {
        }
    }

    fun uninstall(ctx: Context, app: AppItem) {
        try {
            ctx.startActivity(
                Intent(Intent.ACTION_DELETE, Uri.fromParts("package", app.pkg, null))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (_: Exception) {
        }
    }
}
