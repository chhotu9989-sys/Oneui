# Orbit

A glass-style home screen launcher for Android, written in Kotlin and Jetpack Compose.

## What it does

- Shows every installed app on swipeable home pages. Pages tilt and fade in 3D as you swipe, and lower rows trail the swipe slightly.
- Frosted glass panels (dock, clock widget, app drawer, long-press menu). Each one redraws the animated wallpaper blurred behind it, so the glass actually has something to blur. Needs Android 12 or newer for the blur.
- Depth: the wallpaper, stars, icons and dock slide by different amounts when you tilt the phone or swipe between pages.
- Swipe up anywhere on the home screen to open the app drawer with a spring animation. Search by name, press Go to open the first match.
- Long-press an app for App info or Uninstall.
- Apps open with the system zoom-from-icon animation.
- New installs and uninstalls appear automatically. Pressing Home returns to page one.

## Build the APK

### Option 1: Android Studio (on a computer)

1. Install Android Studio.
2. File > Open, choose this folder. If Android Studio asks which Gradle to use, accept its suggestion (Gradle 8.7 or newer), then wait for the sync.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. The file is at `app/build/outputs/apk/debug/app-debug.apk`.

### Option 2: GitHub Actions (no Android Studio)

1. Create a new GitHub repository and upload everything in this folder, including the hidden `.github` folder.
2. Open the Actions tab. The "Build APK" workflow runs on every push, or run it by hand.
3. When it finishes, download `Orbit-debug-apk` from the run page and unzip it.

## Install on the phone

1. Copy `app-debug.apk` to the phone and open it. Allow "install unknown apps" for your file manager or browser when asked.
2. Press Home. Android asks which launcher to use. Choose Orbit and tap Always.
3. To switch back: Settings > Apps > Default apps > Home app.

The debug build is signed with the standard debug key, which is fine for personal use.
